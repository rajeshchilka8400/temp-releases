# Insructions
Below are the instruction to execut commands and run the proejct for finding out why browser is not launching on the machine correctly.
Use powershell if possible.

## Install nodejs

Go to https://radixweb.com/blog/installing-npm-and-nodejs-on-windows-and-mac#windows and follow the instructions. Once, installed visit the directory where you have extracted this project:

```shell
chdir C:\\Path\\To\\open-univesity-browser-launch\\
```

## Setup the project
npm install

## Run the script:

```shell
node nightwatch.js
```
