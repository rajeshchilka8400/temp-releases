
const Nightwatch = require('nightwatch');

const client = Nightwatch.createClient({
  headless: false,
  output: true,
  silent: false, // set to false to enable verbose logging
  browserName: 'chrome', // can be either: firefox, chrome, safari, or edge

  // set the global timeout to be used with waitFor commands and when retrying assertions/expects
  timeout: 10000,

  // any additional capabilities needed
  desiredCapabilities: {
    'goog:chromeOptions': {
      'w3c': true,
      'args': [
        'force-color-profile=srgb',
        'test-type',
        'ignore-certificate-errors',
        'silent-debugger-extension-api',
        'no-default-browser-check',
        'no-first-run',
        'noerrdialogs',
        'enable-fixed-layout',
        'disable-popup-blocking',
        'disable-password-generation',
        'disable-single-click-autofill',
        'disable-prompt-on-repos',
        'disable-background-timer-throttling',
        'disable-renderer-backgrounding',
        'disable-renderer-throttling',
        'disable-backgrounding-occluded-windows',
        'disable-restore-session-state',
        'disable-new-profile-management',
        'disable-new-avatar-menu',
        'allow-insecure-localhost',
        'reduce-security-for-testing',
        'disable-print-preview',
        'disable-device-discovery-notifications',
        'autoplay-policy=no-user-gesture-required',
        'disable-site-isolation-trials',
        'metrics-recording-only',
        'disable-prompt-on-repost',
        'disable-hang-monitor',
        'disable-sync'
      ]
    }
  },

  // can define/overwrite test globals here;
  // when using a third-party test runner only the global hooks onBrowserNavigate/onBrowserQuit are supported
  globals: {},

  // when the test runner used supports running tests in parallel;
  // set to true if you need the webdriver port to be randomly generated
  parallel: false,

  // All other Nightwatch config settings can be overwritten here, such as:
  disable_colors: false
});

(async () => {
  const page = await client.launchBrowser();

  const url = 'https://bstackdemo.com';

  console.log(`visting url: ${url}`);

  await page.url(url);

  await page.click('xpath', '//HTML/BODY[1]/DIV[1]/DIV[1]/DIV[1]/MAIN[1]/DIV[2]/DIV[15]/DIV[4]');

  console.log(`test completed, killing browser`);

  await page.end();
})();
